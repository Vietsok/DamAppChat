package com.samuelvialle.damappchat.Common;

public class Constants {

    // Lien vers le dossier de stockage des avatars
    public static final String IMAGES_FOLDER = "avatars_user";
    public static final String REQUEST_STATUS_SENT = "sent";
    // On en profite profite pour ajouter Received
    public static final String REQUEST_STATUS_RECEIVED = "received";

}
